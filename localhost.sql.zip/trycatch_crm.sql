-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2015 at 04:42 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `trycatch_crm`
--

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_name` text NOT NULL,
  `client_email` text NOT NULL,
  `create_date` int(11) NOT NULL,
  `client_address` text NOT NULL,
  `client_tel` text NOT NULL,
  `client_note` text NOT NULL,
  `client_site` text NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`client_id`, `client_name`, `client_email`, `create_date`, `client_address`, `client_tel`, `client_note`, `client_site`) VALUES
(1, 'คุณ มงคล บุญเรือง', 'conerbeat@hotmail.com', 1361746800, 'มงคลกระเบื้องล้านนา 128 ซ.5 ม.1 ต.ท่าศาลา อ.เมือง จ.เชียงใหม่ 50000', '083-516-3888, 086-530-1411', '', 'mongkholtile.com'),
(2, 'Ms. Pornsri Sujjapongse', 'chitpong@hotmail.com', 1197673200, '36 Moo 1 Paholyothin Road, Tambol Dowrueng Amphur Muang Saraburi', '081-255-0121', 'อย่าลืม Transfer-out จากคุณก๊อต (084-554-9848 / gotzyber@gmail.com) ', 'kasemsukmarble.com'),
(3, 'คุณชัชชัย เพชรอักษร', 'chatpongnoi@hotmail.com', 1389049200, 'สำนักชลประทานที่ 1 เชียงใหม่ เลขที่ 27 ถ.ทุ่งโฮเต็ล อ.เมือง จ.เชียงใหม่ 50000', '086-912-0099', '', 'damlog.com'),
(4, 'บริษัท เชียงใหม่ วนัสนันท์ จำกัด', 'vnscm1@hotmail.com', 1368226800, '398 ถ.เชียงใหม่-ลำปาง ต.ฟ้าฮ่าม อ.เมือง จ.เชียงใหม่ 50000', '081-960-5544', 'เก็บเฉพาะค่าโดเมน 500 บาท', 'vthaitaste.com'),
(7, 'น.ส. ภิตรดา นนท์คำวงค์', 'chiangmaijungletrekking@gmail.com', 1411167600, '121 ถ.มูลเมือง ต.ศรีภูมิ อ.เมือง จ.เชียงใหม่ 50200', '081-035-4836, 084-790-4675', 'โดเมนหมดอายุจริง 2017 ราคาค่า Server 1500 บาท เพราะเป็น Server แยกลูกที่ 2', 'chiangmaijungletrekking.com'),
(5, 'บ้านสวนพันธ์ุสมบัติ', 'groov_dash@hotmail.com', 1394146800, '99/1 หมู่ที่ 4 ต.ขี้เหล็ก อ.แม่ริม จ.เชียงใหม่ 50180', '086-1165218, 081-9617558, 081-6020524, 089-7001273', '', 'bspresort.com'),
(6, 'คุณอำพร ราชทัง', 'pensri21@hotmail.com', 1417993200, '599 หมู่ 5 ต.สันผีเสื้อ อ.เมือง จ.เชียงใหม่', '081-952-4786', '', 'fullmoonresortchiangmai.com'),
(8, 'คุณณพงศ์ นันทราทิพย์', 'chalee.myhipcondo@gmail.com', 1420758000, 'บริษัท โฮม ดีเวลลอปเม้นท์ กรุ๊ป จากัด 96 หมู่ 4 ตาบลหนองป่าครั่ง อาเภอเมือง จังหวัดเชียงใหม่ 50000', '088-263-3893', 'เก็บเฉพาะค่าโดเมน 650 บาท', 'myhipcondo.net'),
(9, 'บริษัท เชียงใหม่ วนัสนันท์ จำกัด', 'vnscm1@hotmail.com', 1372114800, '398 ถ.เชียงใหม่-ลำปาง ต.ฟ้าฮ่าม อ.เมือง จ.เชียงใหม่ 50000', '081-960-5544', 'เก็บเฉพาะค่า Server 1000 บาท โดเมนไม่ได้อยู่กับทาง TryCatch', 'vanusnun.com'),
(10, 'คุณพิรุณ นันทยา', 'piroonnantaya@gmail.com', 1370214000, '89/3 หมู่ 2 ต.ท่าศาลา อ.เมือง จ.เชียงใหม่ 50000', '081-961-1015', 'โดเมนหมดจริง 14-11-2015 แต่จ้างเว็บจริง  03-06-2013', 'chiangmai-trekking.com'),
(11, 'คุณณพงศ์ นันทราทิพย์', 'chalee.myhipcondo@gmail.com', 1375484400, 'บริษัท โฮม ดีเวลลอปเม้นท์ กรุ๊ป จากัด 96 หมู่ 4 ตาบลหนองป่าครั่ง อาเภอเมือง จังหวัดเชียงใหม่ 50000', '088-263-3893', 'เก็บเฉพาะค่าเช่า Server 1000 บาท', 'Myhipcondo.com'),
(12, 'นายศิริชัย ฉายบัณฑิต', 'chaybandit_s@hotmail.com', 1372028400, '153 หมู่ 1 ตาบลสันทรายหลวง อาเภอสันทราย จังหวัดเชียงใหม่ 50210', '0833228008', '', 'theelysiumgarden.com'),
(13, 'กลุ่มบริษัท อินเตอร์กรุ๊ป', 'i.intergroup2014@gmail.com', 1414969200, '229/265 อาคารปันนาเรสซิเดินท์แอทซีเอ็มยู หมู่ 14 ถ.ห้วยแก้ว ต.สุเทพ จ.เชียงใหม่ 50200 ', '053-142-363, 091-067-9551', '', 'i-intergroup.com');

-- --------------------------------------------------------

--
-- Table structure for table `email`
--

CREATE TABLE IF NOT EXISTS `email` (
  `email_id` int(11) NOT NULL AUTO_INCREMENT,
  `email_name` text NOT NULL,
  PRIMARY KEY (`email_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `email`
--

INSERT INTO `email` (`email_id`, `email_name`) VALUES
(1, 'แบบฟอร์มยืนยันวันการจ่ายเงิน');

-- --------------------------------------------------------

--
-- Table structure for table `email_feedback`
--

CREATE TABLE IF NOT EXISTS `email_feedback` (
  `fb_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `email_id` int(11) NOT NULL,
  `feedback` text NOT NULL,
  PRIMARY KEY (`fb_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `password` varchar(128) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `username`, `password`) VALUES
(1, 'keittirat@gmail.com', 'af6ed6c8ce1b06c5c8e20ccdfefc8d85');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
